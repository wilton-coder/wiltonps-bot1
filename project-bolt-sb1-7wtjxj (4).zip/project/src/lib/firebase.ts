import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyBJMGCNjlWkAW62EqFiAckaYGLzePQ4FuE",
  authDomain: "imovel-cumbuco-c0c56.firebaseapp.com",
  projectId: "imovel-cumbuco-c0c56",
  storageBucket: "imovel-cumbuco-c0c56.firebasestorage.app",
  messagingSenderId: "175739436561",
  appId: "1:175739436561:web:3a56109ca38fdfc8ed3bb0"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);