import { collection, addDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { trackLeadEvent } from './pixel';
import { ContactFormData } from '../types/contact';

export const submitContactForm = async (formData: ContactFormData) => {
  try {
    const contactsRef = collection(db, 'contacts');
    const docRef = await addDoc(contactsRef, {
      ...formData,
      createdAt: new Date().toISOString()
    });
    
    // Track the lead event with Meta Pixel
    trackLeadEvent(formData);
    
    return { success: true, id: docRef.id };
  } catch (error) {
    console.error('Error submitting form:', error);
    return { success: false, error };
  }
};