import { ContactFormData } from '../types/contact';

declare global {
  interface Window {
    fbq: any;
  }
}

export const trackLeadEvent = (formData: ContactFormData) => {
  if (window.fbq) {
    window.fbq('track', 'Lead', {
      content_name: 'Agendamento de Visita',
      content_category: 'Formulário de Contato',
      value: 0,
      currency: 'BRL',
      status: 'Novo Lead',
      email: formData.email,
      phone: formData.phone,
      name: formData.name,
      preferred_date: formData.preferredDate
    });
  }
};