import React from 'react';
import { Quote } from 'lucide-react';

const Testimonials = () => {
  const testimonials = [
    {
      text: "Desde a primeira visita, soubemos que aqui era o nosso lugar. A energia da Praia do Cumbuco e o conforto da casa são inigualáveis.",
      author: "Roberto Silva",
      role: "Empresário"
    },
    {
      text: "A combinação perfeita entre luxo e natureza. Poder praticar kitesurf e voltar para uma casa tão aconchegante é um privilégio.",
      author: "Ana Costa",
      role: "Atleta Profissional"
    }
  ];

  return (
    <section id="depoimentos" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        <h2 className="text-4xl font-light text-center mb-16">O que dizem nossos proprietários</h2>
        <div className="grid md:grid-cols-2 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-white p-8 rounded-lg shadow-sm">
              <Quote className="text-blue-600 w-8 h-8 mb-4" />
              <p className="text-gray-600 mb-6">{testimonial.text}</p>
              <div>
                <p className="font-semibold">{testimonial.author}</p>
                <p className="text-gray-500">{testimonial.role}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;