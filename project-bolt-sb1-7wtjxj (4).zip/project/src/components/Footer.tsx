import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-gray-400 py-12">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-white text-lg font-semibold mb-4">CUMBUCO</h3>
            <p className="text-sm">
              Seu refúgio de luxo na capital nacional do kitesurf.
            </p>
          </div>
          <div>
            <h3 className="text-white text-lg font-semibold mb-4">Contato</h3>
            <p className="text-sm">Email: exclusivo@cumbucoluxury.online</p>
          </div>
          <div>
            <h3 className="text-white text-lg font-semibold mb-4">Legal</h3>
            <div className="space-y-2">
              <a href="#" className="block text-sm hover:text-white transition">
                Política de Privacidade
              </a>
              <a href="#" className="block text-sm hover:text-white transition">
                Termos de Uso
              </a>
            </div>
          </div>
        </div>
        <div className="border-t border-gray-800 mt-12 pt-8 text-center text-sm">
          © {new Date().getFullYear()} Cumbuco Luxury. Todos os direitos reservados.
        </div>
      </div>
    </footer>
  );
};

export default Footer;