import React, { useState } from 'react';
import { submitContactForm } from '../../services/contact';
import { ContactFormData } from '../../types/contact';
import ContactFormFields from './ContactFormFields';
import SuccessMessage from './SuccessMessage';

const ContactForm = () => {
  const [formData, setFormData] = useState<ContactFormData>({
    name: '',
    email: '',
    phone: '',
    preferredDate: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus('idle');
    
    try {
      const result = await submitContactForm(formData);
      if (result.success) {
        setSubmitStatus('success');
        setFormData({ name: '', email: '', phone: '', preferredDate: '' });
      } else {
        setSubmitStatus('error');
      }
    } catch (error) {
      console.error('Form submission error:', error);
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <section id="contact-form" className="py-24 bg-white">
      <div className="max-w-3xl mx-auto px-6">
        <h2 className="text-4xl font-light text-center mb-8">
          Solicite mais informações ou agende sua visita VIP
        </h2>
        {submitStatus === 'success' ? (
          <SuccessMessage />
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            <ContactFormFields formData={formData} onChange={handleChange} />
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSubmitting ? 'Enviando...' : 'Solicitar Visita VIP'}
            </button>
            {submitStatus === 'error' && (
              <p className="text-red-600 text-center">
                Ocorreu um erro. Por favor, tente novamente.
              </p>
            )}
          </form>
        )}
        <p className="text-center text-sm text-gray-500 mt-6">
          Respeitamos sua privacidade. Suas informações estão 100% seguras conosco.
        </p>
      </div>
    </section>
  );
};

export default ContactForm;