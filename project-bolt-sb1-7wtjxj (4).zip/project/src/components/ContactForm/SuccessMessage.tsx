import React from 'react';

const SuccessMessage = () => {
  return (
    <div className="text-center p-6 bg-green-50 rounded-lg">
      <p className="text-green-600 font-medium">
        Obrigado! Entraremos em contato em breve.
      </p>
    </div>
  );
};

export default SuccessMessage;