import React, { useState } from 'react';
import { submitContactForm } from '../services/contact';

const ContactForm = () => {
  const [formData, setFormData] = useState({
    email: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus('idle');
    
    try {
      const result = await submitContactForm(formData);
      if (result.success) {
        setSubmitStatus('success');
        setFormData({ email: '' });
      } else {
        setSubmitStatus('error');
      }
    } catch (error) {
      console.error('Form submission error:', error);
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <section id="contact-form" className="py-24 bg-white">
      <div className="max-w-3xl mx-auto px-6">
        <h2 className="text-4xl font-light text-center mb-8">
          Solicite mais informações ou agende sua visita VIP
        </h2>
        {submitStatus === 'success' ? (
          <div className="text-center p-6 bg-green-50 rounded-lg">
            <p className="text-green-600 font-medium">
              Obrigado! Em breve entraremos em contato.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                E-mail
              </label>
              <input
                type="email"
                id="email"
                name="email"
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                value={formData.email}
                onChange={handleChange}
              />
            </div>
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSubmitting ? 'Enviando...' : 'Solicitar Visita Exclusiva'}
            </button>
            {submitStatus === 'error' && (
              <p className="text-red-600 text-center">
                Ocorreu um erro. Por favor, tente novamente.
              </p>
            )}
          </form>
        )}
        <p className="text-center text-sm text-gray-500 mt-6">
          Respeitamos sua privacidade. Suas informações estão 100% seguras conosco.
        </p>
      </div>
    </section>
  );
};

export default ContactForm;