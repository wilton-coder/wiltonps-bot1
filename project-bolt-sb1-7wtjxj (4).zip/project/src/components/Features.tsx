import React from 'react';
import { Compass, Shield, Dumbbell, Home } from 'lucide-react';
import ImageSlider from './ImageSlider';

const Features = () => {
  const features = [
    {
      icon: <Compass className="w-8 h-8" />,
      title: 'Localização Premium',
      description: 'Praia do Cumbuco, o paraíso dos esportes aquáticos e do kitesurf.'
    },
    {
      icon: <Home className="w-8 h-8" />,
      title: 'Arquitetura Moderna',
      description: 'Projetado para quem busca conforto e exclusividade.'
    },
    {
      icon: <Shield className="w-8 h-8" />,
      title: 'Segurança e Privacidade',
      description: 'Sistemas de última geração para sua total tranquilidade.'
    },
    {
      icon: <Dumbbell className="w-8 h-8" />,
      title: 'Lazer Completo',
      description: 'Piscina, spa, academia e espaços gourmet, tudo integrado à natureza.'
    }
  ];

  return (
    <section id="destaques" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="mb-16">
          <ImageSlider />
        </div>
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-light mb-6">Um Refúgio de Luxo à Beira-mar</h2>
            <p className="text-gray-600 mb-8">
              Aqui, a brisa do mar não é só um convite ao descanso, mas um símbolo de liberdade.
              Viver na Praia do Cumbuco é mais do que ter uma casa de alto padrão. É abraçar um
              estilo de vida onde o luxo e a liberdade caminham juntos.
            </p>
            <div className="grid gap-8 sm:grid-cols-2">
              {features.map((feature, index) => (
                <div key={index} className="flex gap-4">
                  <div className="text-blue-600 flex-shrink-0">{feature.icon}</div>
                  <div>
                    <h3 className="font-semibold mb-2">{feature.title}</h3>
                    <p className="text-gray-600 text-sm">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="aspect-[4/3] relative rounded-lg overflow-hidden mt-8 lg:mt-0">
            <img
              src="https://i.imgur.com/o3yOboK.jpeg"
              alt="Vista principal"
              className="absolute inset-0 w-full h-full object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;