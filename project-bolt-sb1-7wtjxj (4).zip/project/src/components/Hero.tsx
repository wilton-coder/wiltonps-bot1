import React from 'react';
import { ChevronDown } from 'lucide-react';

const Hero = () => {
  const scrollToForm = () => {
    document.getElementById('contact-form')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative h-screen">
      {/* Preload hero image */}
      <link 
        rel="preload" 
        as="image" 
        href="https://i.imgur.com/vkPEhee.jpeg" 
      />
      
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat will-change-transform"
        style={{
          backgroundImage: 'url("https://i.imgur.com/vkPEhee.jpeg")',
          transform: 'translateZ(0)', // Force GPU acceleration
        }}
      >
        <div className="absolute inset-0 bg-black/40 backdrop-filter backdrop-brightness-75" />
      </div>
      
      <div className="relative h-full flex items-center">
        <div className="max-w-7xl mx-auto px-6 text-white">
          <h1 className="text-4xl sm:text-5xl md:text-7xl font-light mb-6 animate-fade-in">
            Liberdade e Luxo na Capital Nacional do Kitesurf
          </h1>
          <p className="text-lg sm:text-xl md:text-2xl mb-8 max-w-3xl animate-fade-in-delay">
            Na Praia do Cumbuco, viver é sinônimo de exclusividade, aventura e conforto absoluto.
          </p>
          <button
            onClick={scrollToForm}
            className="bg-white text-gray-900 px-6 sm:px-8 py-3 sm:py-4 rounded-full text-base sm:text-lg hover:bg-gray-100 transition transform hover:scale-105 animate-fade-in-delay-2"
          >
            Agendar Visita VIP
          </button>
        </div>
      </div>

      <button 
        onClick={() => document.getElementById('destaques')?.scrollIntoView({ behavior: 'smooth' })}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-white animate-bounce"
        aria-label="Rolar para baixo"
      >
        <ChevronDown size={32} />
      </button>
    </section>
  );
};

export default Hero;