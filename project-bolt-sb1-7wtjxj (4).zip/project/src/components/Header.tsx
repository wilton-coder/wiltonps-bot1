import React, { useState } from 'react';
import { Menu, Phone, X } from 'lucide-react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const scrollToForm = () => {
    document.getElementById('contact-form')?.scrollIntoView({ behavior: 'smooth' });
    setIsMenuOpen(false);
  };

  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    setIsMenuOpen(false);
  };

  return (
    <header className="fixed w-full bg-white/90 backdrop-blur-sm z-50 py-4 px-6 shadow-sm">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="text-2xl font-light tracking-wider">CUMBUCO</div>
        
        {/* Mobile Menu Button */}
        <button 
          className="md:hidden z-50"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8 text-gray-600">
          <button onClick={() => scrollToSection('inicio')} className="hover:text-gray-900 transition">Início</button>
          <button onClick={() => scrollToSection('destaques')} className="hover:text-gray-900 transition">Destaques</button>
          <button onClick={() => scrollToSection('depoimentos')} className="hover:text-gray-900 transition">Depoimentos</button>
          <button onClick={scrollToForm} className="hover:text-gray-900 transition">Contato</button>
        </nav>

        {/* Mobile Navigation */}
        <div className={`fixed inset-0 bg-white/95 backdrop-blur-sm transition-transform duration-300 ${isMenuOpen ? 'translate-x-0' : 'translate-x-full'} md:hidden`}>
          <div className="flex flex-col items-center justify-center h-full space-y-8 text-xl">
            <button onClick={() => scrollToSection('inicio')} className="hover:text-gray-900 transition">Início</button>
            <button onClick={() => scrollToSection('destaques')} className="hover:text-gray-900 transition">Destaques</button>
            <button onClick={() => scrollToSection('depoimentos')} className="hover:text-gray-900 transition">Depoimentos</button>
            <button onClick={scrollToForm} className="hover:text-gray-900 transition">Contato</button>
          </div>
        </div>

        {/* CTA Button */}
        <button
          onClick={scrollToForm}
          className="hidden md:flex items-center gap-2 bg-blue-600 text-white px-6 py-2 rounded-full hover:bg-blue-700 transition"
        >
          <Phone size={18} />
          <span>Agendar Visita</span>
        </button>
      </div>
    </header>
  );
};

export default Header;