import React from 'react';
import { Bitcoin, FileText, Handshake } from 'lucide-react';

const PaymentInfo = () => {
  return (
    <section className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        <h2 className="text-4xl font-light text-center mb-16">
          Negociação Descomplicada, Pagamento Flexível
        </h2>
        
        <div className="grid md:grid-cols-3 gap-12 mb-16">
          <div className="text-center group">
            <div className="mb-6 flex justify-center">
              <FileText className="w-12 h-12 text-blue-600 transition-transform group-hover:scale-110" />
            </div>
            <h3 className="text-xl font-semibold mb-4">Processo Simplificado</h3>
            <p className="text-gray-600">
              Simplificamos o processo para você. Nossa abordagem moderna e desburocratizada 
              torna sua aquisição ainda mais fácil e rápida.
            </p>
          </div>
          
          <div className="text-center group">
            <div className="mb-6 flex justify-center">
              <Bitcoin className="w-12 h-12 text-blue-600 transition-transform group-hover:scale-110" />
            </div>
            <h3 className="text-xl font-semibold mb-4">Criptoativos</h3>
            <p className="text-gray-600">
              Aceitamos criptoativos como parte da negociação, oferecendo mais 
              flexibilidade e modernidade nas transações.
            </p>
          </div>
          
          <div className="text-center group">
            <div className="mb-6 flex justify-center">
              <Handshake className="w-12 h-12 text-blue-600 transition-transform group-hover:scale-110" />
            </div>
            <h3 className="text-xl font-semibold mb-4">Negociação Flexível</h3>
            <p className="text-gray-600">
              Estamos abertos a propostas personalizadas, garantindo uma experiência 
              de compra exclusiva e adaptada às suas necessidades.
            </p>
          </div>
        </div>
        
        <div className="text-center">
          <p className="text-xl text-gray-600 italic mb-8">
            "Porque entendemos que o luxo é também sobre liberdade de escolha."
          </p>
          <button
            onClick={() => document.getElementById('contact-form')?.scrollIntoView({ behavior: 'smooth' })}
            className="bg-blue-600 text-white px-8 py-4 rounded-full hover:bg-blue-700 transition"
          >
            Quer saber mais sobre nossas condições exclusivas?
          </button>
        </div>
      </div>
    </section>
  );
};

export default PaymentInfo;