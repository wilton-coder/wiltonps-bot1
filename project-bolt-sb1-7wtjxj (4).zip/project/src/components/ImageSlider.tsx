import React from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Pagination, Autoplay } from 'swiper/modules';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';

const images = [
  { url: 'https://i.imgur.com/o3yOboK.jpeg', alt: 'Vista da propriedade 1' },
  { url: 'https://i.imgur.com/RDCTaSA.jpeg', alt: 'Vista da propriedade 2' },
  { url: 'https://i.imgur.com/ov29BBX.jpeg', alt: 'Vista da propriedade 3' },
  { url: 'https://i.imgur.com/ZLijyQ9.jpeg', alt: 'Vista da propriedade 4' },
  { url: 'https://i.imgur.com/6jgxa9p.jpeg', alt: 'Vista da propriedade 5' },
  { url: 'https://i.imgur.com/BHOTz7N.jpeg', alt: 'Vista da propriedade 6' },
  { url: 'https://i.imgur.com/vs8jKHd.jpeg', alt: 'Vista da propriedade 7' },
  { url: 'https://i.imgur.com/laZHgb2.jpeg', alt: 'Vista da propriedade 8' },
  { url: 'https://i.imgur.com/I7zd677.jpeg', alt: 'Vista da propriedade 9' },
  { url: 'https://i.imgur.com/Dc75EKu.jpeg', alt: 'Vista da propriedade 10' },
  { url: 'https://i.imgur.com/Hjui7OK.jpeg', alt: 'Vista da propriedade 11' },
  { url: 'https://i.imgur.com/slO9ETD.jpeg', alt: 'Vista da propriedade 12' },
  { url: 'https://i.imgur.com/xC4WfFq.jpeg', alt: 'Vista da propriedade 13' },
  { url: 'https://i.imgur.com/oqV8dby.jpeg', alt: 'Vista da propriedade 14' },
  { url: 'https://i.imgur.com/cuerPre.jpeg', alt: 'Vista da propriedade 15' },
  { url: 'https://i.imgur.com/KxaK2lS.jpeg', alt: 'Vista da propriedade 16' },
  { url: 'https://i.imgur.com/WFKvGaa.jpeg', alt: 'Vista da propriedade 17' },
  { url: 'https://i.imgur.com/LSu5AF8.jpeg', alt: 'Vista da propriedade 18' }
];

const ImageSlider = () => {
  return (
    <div className="w-full">
      <Swiper
        modules={[Navigation, Pagination, Autoplay]}
        spaceBetween={16}
        slidesPerView={1}
        navigation
        pagination={{ clickable: true }}
        autoplay={{ delay: 5000, disableOnInteraction: false }}
        loop={true}
        className="w-full aspect-[16/9] rounded-lg overflow-hidden"
        breakpoints={{
          640: {
            slidesPerView: 1,
            spaceBetween: 16,
          },
          768: {
            slidesPerView: 2,
            spaceBetween: 16,
          },
          1024: {
            slidesPerView: 3,
            spaceBetween: 16,
          },
        }}
      >
        {images.map((image, index) => (
          <SwiperSlide key={index}>
            <div className="relative w-full h-full group">
              <img
                src={image.url}
                alt={image.alt}
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
    </div>
  );
};

export default ImageSlider;